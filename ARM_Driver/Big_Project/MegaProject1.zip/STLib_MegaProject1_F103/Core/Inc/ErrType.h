#ifndef ERRTYPE_H_
#define ERRTYPE_H_

#define NULL			(void*) 0

#define OK              1U
#define NOK             2U
#define NULL_PTR_ERR    3U
#define TIMEOUT         4U

#endif